package com.ssafy.farmyo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmyoApplicationTests {

	@Test
	void contextLoads() {
	}

}
