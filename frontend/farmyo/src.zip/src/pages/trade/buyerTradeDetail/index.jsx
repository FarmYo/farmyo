import BuyerTrade from "../../../component/trade/buyerTradeDetail/index"

export default function BuyerTradePage() {
  return <BuyerTrade />
}