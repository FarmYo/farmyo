import SellerTrade from "../../../component/trade/sellerTradeDetail";

export default function SellerTradePage() {
  return <SellerTrade />
}