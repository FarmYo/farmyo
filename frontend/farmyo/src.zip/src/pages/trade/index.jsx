import Trade from "../../component/trade";

export default function TradePage() {
  return <Trade />
}