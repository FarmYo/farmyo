import MypageNavbar from "../../../component/mypage/buyernav"

export default function SellerMypage () {
  return (
    <div>
      <MypageNavbar />
    </div>
  )
}