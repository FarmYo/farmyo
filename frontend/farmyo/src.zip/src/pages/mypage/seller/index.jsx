import MypageNavbar from "../../../component/mypage/sellernav"

export default function SellerMypage () {
  return (
    <div>
      <MypageNavbar />
    </div>
  )
}