import SignUp from "../../../component/user/signUp/index"

export default function SignUpPage () {
  return (
    <div>
      <SignUp />
    </div>
  )
}