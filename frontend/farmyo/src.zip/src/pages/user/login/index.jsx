import LoginInput from "../../../component/user/login/index"

export default function LoginPage () {
  return (
    <div>
      <LoginInput />
    </div>
  )
}