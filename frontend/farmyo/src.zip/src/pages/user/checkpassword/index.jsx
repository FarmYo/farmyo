import CheckPassword from "../../../component/user/checkpassword/index"

export default function CheckPasswordPage () {
  return (
    <div>
      <CheckPassword />
    </div>
  )
}