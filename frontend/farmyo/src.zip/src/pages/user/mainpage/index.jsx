import Mainpage from "../../../component/user/mainpage"

export default function MainPage () {
  return (
    <div>
      <Mainpage />
    </div>
  )
}